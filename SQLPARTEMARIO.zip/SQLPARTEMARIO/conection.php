<?php
//Variables de acceso

//nombre del server
$db_server = "localhost";
//puerto asignado
$db_port = ":3307"; //El número de puerto se debe cambiar dependiendo de cual diga XAMPP en el apartado de mySQL
//usuario
$db_username = "root";
//contraseña
$db_password = "";
//nombre de la base de datos
$db_name = "xtreme";

// Crear la conexion
$conn = mysqli_connect($db_server.$db_port, $db_username, $db_password, $db_name);
?>